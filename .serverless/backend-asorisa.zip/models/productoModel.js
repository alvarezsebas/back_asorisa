export const ProductoModel = {
  id_producto: 0,             // number
  nombre: '',        // string
  descripcion: '',   // string
  valor: 0,          // number
  categoriaId: 0,    // number
};